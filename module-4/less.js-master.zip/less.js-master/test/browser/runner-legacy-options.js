var less = {
    logLevel: 4,
    errorReporting: 'console',
    math: 'always',
    strictUnits: false
};
